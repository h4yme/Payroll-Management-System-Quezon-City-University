import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

@WebServlet("/RegistrationServlet")
@MultipartConfig
public class Registration extends HttpServlet {
    Connection con;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            response.setContentType("text/html");
            PrintWriter out = response.getWriter();

            // Load the MySQL JDBC driver
            Class.forName("com.mysql.jdbc.Driver");

            // Establish the database connection
            con = DriverManager.getConnection("jdbc:mysql://localhost/payroll_management_system", "root", "");

            // Get user input
            String id = request.getParameter("id");
            String firstname = request.getParameter("firstname");
            String lastname = request.getParameter("surname");
            String fullname = firstname + " " + lastname;
            String gend = request.getParameter("gender");
            String dob = request.getParameter("dob");
            String usn = request.getParameter("username");
            String email = request.getParameter("email");
            String password = request.getParameter("password");
            String address = request.getParameter("address");
            String jobtitle = request.getParameter("jobtitle");
            String datehired = request.getParameter("datehired");
            String bi = request.getParameter("bio");
            String cont = request.getParameter("contact");
            String securityQuestion = request.getParameter("securityquestion");
            String basicsalary = request.getParameter("basicsalary");
            String answer = request.getParameter("answer");

            // Handle image upload
            Part filePart = request.getPart("image");
            InputStream imageInputStream = filePart.getInputStream();

            // Insert data into the database
            PreparedStatement pst = con.prepareStatement("INSERT INTO db_login(EmpID, FullName, Gender, Dob, UserName, Email,Contact, Password, Address, Jobtitle, Datehired, Bio, Securityquestion, Basicsalary, Answer, Image) VALUES (?,?,?,?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            pst.setString(1, id);
            pst.setString(2, fullname);
            pst.setString(3, gend);
            pst.setDate(4, java.sql.Date.valueOf(dob));
            pst.setString(5, usn);
            pst.setString(6, email);
             pst.setString(7, cont);
            pst.setString(8, password);
            pst.setString(9, address);
            pst.setString(10, jobtitle);
            pst.setDate(11, java.sql.Date.valueOf(datehired));
             pst.setString(12, bi);
            pst.setString(13, securityQuestion);
            pst.setDouble(14, Double.parseDouble(basicsalary));
            pst.setString(15, answer);
            pst.setBlob(16, imageInputStream);
            pst.executeUpdate();

            out.println("<script>alert('Thank You For Your Registration!');</script>");
           
        } catch (ClassNotFoundException | SQLException ex) {
            // Log any exceptions
            Logger.getLogger(Registration.class.getName()).log(Level.SEVERE, null, ex);

            // Handle the exception and provide feedback to the user
            response.getWriter().println("An error occurred during registration. Please try again later.");
            
        }  finally {
            try {
                // Close the database connection
                if (con != null) {
                    con.close();
                }
            } catch (SQLException ex) {
                Logger.getLogger(Registration.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
}