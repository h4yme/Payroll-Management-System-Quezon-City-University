import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

@WebServlet("/RegistrationServlet")
@MultipartConfig
public class RegistrationServlet extends HttpServlet {
    Connection con;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            response.setContentType("text/html");
            PrintWriter out = response.getWriter();

            // Load the MySQL JDBC driver
            Class.forName("com.mysql.jdbc.Driver");

            // Establish the database connection
            con = DriverManager.getConnection("jdbc:mysql://localhost/payroll_management_system", "root", "");

            // Get user input
            String id = request.getParameter("id");
            String firstname = request.getParameter("fullname");
            String dob = request.getParameter("dob");
            String usn = request.getParameter("username");
            String email = request.getParameter("email");
            String password = request.getParameter("password");
            String address = request.getParameter("address");
            String jobtitle = request.getParameter("jobtitle");
            String datehired = request.getParameter("datehired");
            String securityQuestion = request.getParameter("securityquestion");
            String basicsalary = request.getParameter("basicsalary");
            String answer = request.getParameter("answer");

            // Handle image upload  
            Part filePart = request.getPart("image");
            InputStream imageInputStream = filePart.getInputStream();

            // Insert data into the database
           PreparedStatement pst = con.prepareStatement("INSERT INTO db_login(EmpID, FullName, Dob, UserName, Email, Password, Address, Jobtitle, Datehired, Securityquestion, Basicsalary, Answer, Image) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
           pst.setString(1, id);
           pst.setString(2, firstname);
           pst.setDate(3, java.sql.Date.valueOf(dob)); // Use setDate for date values
           pst.setString(4, usn);
           pst.setString(5, email);
           pst.setString(6, password);
           pst.setString(7, address);
           pst.setString(8, jobtitle);
           pst.setDate(9, java.sql.Date.valueOf(datehired)); // Use setDate for date values
           pst.setString(10, securityQuestion);
           pst.setDouble(11, Double.parseDouble(basicsalary)); // Use setDouble for numeric values
           pst.setString(12, answer);
           pst.setBlob(13, imageInputStream);
           pst.executeUpdate();


            out.println("Thank You For Your Registration!");
            
        } catch (ClassNotFoundException | SQLException ex) {
            // Log any exceptions
            Logger.getLogger(RegistrationServlet.class.getName()).log(Level.SEVERE, null, ex);

            // Handle the exception and provide feedback to the user
            response.getWriter().println("An error occurred during registration. Please try again later.");
        } finally {
            try {
                // Close the database connection
                if (con != null) {
                    con.close();
                }
            } catch (SQLException ex) {
                Logger.getLogger(RegistrationServlet.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
}