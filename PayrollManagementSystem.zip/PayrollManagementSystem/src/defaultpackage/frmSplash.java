package defaultpackage;

import javax.swing.*;
import java.awt.*;
import java.util.Timer;
import java.util.TimerTask;

public class frmSplash {
    private JLabel SplashImage;
    private JWindow window;

    public frmSplash(int duration) {
        window = new JWindow();
        JPanel panel = (JPanel) window.getContentPane();

        // Loading image from resources
        ImageIcon icon = new ImageIcon(getClass().getResource("/images/Final.gif"));
        SplashImage = new JLabel(icon);

        panel.add(SplashImage, BorderLayout.CENTER);

        Dimension screen = Toolkit.getDefaultToolkit().getScreenSize();
        window.setBounds((screen.width - 490) / 2, (screen.height - 300) / 2, 504, 266);

        window.setVisible(true);

        Timer timer = new Timer();
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                window.setVisible(false);
                window.dispose();
                createAndDisplayLoginWindow();
            }
        }, duration);
    }

    private void createAndDisplayLoginWindow() {
        java.awt.EventQueue.invokeLater(() -> {
            Login_Window frame = new Login_Window();
            frame.setLocationRelativeTo(null);
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.pack();
            frame.setVisible(true);
            frame.setResizable(false);
        });
    }
}
