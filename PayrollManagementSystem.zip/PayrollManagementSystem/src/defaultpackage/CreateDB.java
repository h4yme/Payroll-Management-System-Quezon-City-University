/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package defaultpackage;

/**
 *
 * @author Manicar
 */
 
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
 

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Santosh
 */
public class CreateDB 
{
   public static Connection getConnection() {
    String driver = "com.mysql.jdbc.Driver";
    String url = "jdbc:mysql://localhost:3306/payroll_management_system";
    String username = "root";
    String password = "";

    try {
        Class.forName(driver);
        Connection con = DriverManager.getConnection(url, username, password);
        return con;
    } catch (ClassNotFoundException ex) {
        Logger.getLogger(CreateDB.class.getName()).log(Level.SEVERE, "Driver not found", ex);
    } catch (SQLException ex) {
        Logger.getLogger(CreateDB.class.getName()).log(Level.SEVERE, "Error connecting to database", ex);
    }
    return null;
}
}

